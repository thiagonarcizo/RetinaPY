Copyright(c) 2018 TTheoretical & Experimental Epistemology Lab (TEEL), School of Optometry and Vision Science, University of Waterloo, 200
University Ave. West Waterloo, ON, Canada N2L 3G1. All rights reserved.

This Data-set contains 206 fovea-centered OCT images of adult healthy retina.
Please use the following citation if you use the dataset:
Peyman Gholami, Priyanka Roy, Mohana Kuppuswamy Parthasarathy, Vasudevan Lakshminarayanan,
"OCTID: Optical Coherence Tomography Image Database", arXiv preprint arXiv:1812.07056, (2018).

For more information and details about the database see: https://arxiv.org/abs/1812.07056
